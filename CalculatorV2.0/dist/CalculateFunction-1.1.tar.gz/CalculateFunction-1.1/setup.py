from setuptools import setup

setup(
	name='CalculateFunction',
	version='1.01',
	description='Calculator',
	author='Vika Matveeva',
	py_modules=['CalculateFunction']
)
